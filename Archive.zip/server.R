# Markus Gesmann, February 2013
require(googleVis)
require(shiny)
require(RCurl)
require(RJSONIO)
require(dismo)
require(maps)
require(XML)

construct.geocode.url <- function(address, return.call = "json", sensor = "false") {
  root <- "http://maps.google.com/maps/api/geocode/"
  u <- paste(root, return.call, "?address=", address, "&sensor=", sensor, sep = "")
  return(URLencode(u))
}

gGeoCode <- function(address,verbose=FALSE) {
  if(verbose) cat(address,"\n")
  u <- construct.geocode.url(address)
  doc <- getURL(u)
  x <- fromJSON(doc,simplify = FALSE)
  if(x$status=="OK") {
    lat <- x$results[[1]]$geometry$location$lat
    lng <- x$results[[1]]$geometry$location$lng
    return(c(lat, lng))
  } else {
    return(c(NA,NA))
  }
}

gGeoState <- function(address,verbose=FALSE) {
  if(verbose) cat(address,"\n")
  u <- construct.geocode.url(address)
  doc <- getURL(u)
  x <- fromJSON(doc,simplify = FALSE)
  if(x$status=="OK") {
    return(x)
  } else {
    return(NA)
  }
}
# $address_components[[5]]$short_name



load("Medicare_Data.Rda")

proc <- unique(data$DRG.Definition)

data$locationvar <- paste0(data$lat, ":", data$long)


shinyServer(function(input, output) {
  
#   print(input$proc)
  dataset <- reactive({
    print(input$proc)
    df <- data[data$DRG.Definition == input$proc, ]
  })
  
#   myYear <- reactive({
#     input$Year
#   })
  
  output$add <- renderText({
    paste("Address is", input$address)
  })

  output$Controls <- renderUI({
    selectInput("proc", "Please Select Procedure Category", proc)
  })  
  
  output$gvis <- renderGvis({
    df <- dataset()
    # print(head(df))
    dd <- gGeoState(input$address)
    print(head(dd))
    state <- dd$address_components[[5]]$short_name
    reg <- ifelse(!is.na(state), paste0("US-", state), "US")
    gvisGeoMap(df,
                 locationvar="locationvar", numvar="Average.Total.Payments",
                 options=list(region=reg, dataMode="Markers", 
                              width=500, height=400,
                              colorAxis="{colors:['#FFFFFF', '#0000FF']}"
                       ))     
#     gvisMap(df,
#                locationvar="locationvar", tipvar="Average.Total.Payments")       
  })
})